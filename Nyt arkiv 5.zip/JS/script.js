const TIME_OUT = 600 // It should be the same transition time of the sections
const body = document.querySelector('body')
const sectionsQty = document.querySelectorAll('section').length
const sectionStick = document.querySelector('.section-stick')

let startFlag = true
let initialScroll = window.scrollY
let qty = 1,
  main = null,
  next = null

// Add child elements in .section-stick as number of sections exist
Array(sectionsQty)
  .fill()
  .forEach(() => {
    sectionStick.innerHTML = sectionStick.innerHTML + '<div class="stick"></div>'
  })

console.log('SLIDE', qty)

// Listening to scroll event
window.onscroll = () => {
  if (startFlag) {
    const scrollDown = this.scrollY >= initialScroll
    const scrollLimit = qty >= 1 && qty <= sectionsQty

    // Verify that the scroll does not exceed the number of sections
    if (scrollLimit) {
      body.style.overflowY = 'hidden' // Lock el scroll

      if (scrollDown && qty < sectionsQty) {
        main = document.querySelector(`section.s${qty}`)
        next = document.querySelector(`section.s${qty + 1}`)

        main.style.transform = 'translateY(-100vh)'
        next.style.transform = 'translateY(0)'

        qty++
      } else if (!scrollDown && qty > 1) {
        main = document.querySelector(`section.s${qty - 1}`)
        next = document.querySelector(`section.s${qty}`)

        main.style.transform = 'translateY(0)'
        next.style.transform = 'translateY(100vh)'

        qty
      }

      // Scroll progressbar
      const active = document.querySelector('.section-stick .stick.active')
      active.style.top = (62 + 30) * (qty - 1) + 'px'
    }

    console.log('SLIDE', qty)

    // Wait for the scrolling to finish to reset the values
    setTimeout(() => {
      initialScroll = this.scrollY
      startFlag = true
      body.style.overflowY = 'scroll' // Unlock scroll
    }, TIME_OUT)

    startFlag = false
  }

  // Keep scrollbar in the middle of the viewport
  window.scroll(0, window.screen.height)
}


document.getElementById('s2').innerHTML= `
<div class = "txt" id = "TxtPage0">

<p>Der var engang en ung kvinde som skulle igang med resten af sit liv, hun startede på erhvervsakademi Aarhus. Men bar på et lille mirakel i maven. Hun kom ind i en klasse fyldt med unge mennesker, og følte sig ensom og malplaceret. 
  </p>
</div>
<img src="img/trae3.svg" alt="skolen skinner" class="pictures" id="tree1">
<img src="img/Hovedperson-05-Hovedperson-nervøs.svg" alt="Hovedpersonen til historien" class = "pictures" id = "hovedPersonPage1">
<img src="img/skole.svg" alt="Skolen som baggrund" class="pictures" id="skole">   
<img src="img/Elementer-07-Skyggepersoner.svg" alt="shadowpeople" class="pictures" id="shadowPeople">
<img src="img/trae2.svg" alt="skolen skinner" class="pictures" id="tree2">
 
`;

document.getElementById('s3').innerHTML= `<div class = "section" id = "section1">
<div class = "txt" id = "TxtPage1">
<p>Tiden gik og pludselig stod hun med en kæmpe rund mave og en eksamen lige om hjørnet. Panikken steg, og hun bad til et mirakel fra de højere magter om at alt ville gå godt. 
      
Eksamen hun bestod og babyen kom ud. </p> </div>

     
      
        <img src="img/kalender.svg" alt="kalenderen" class="pictures" id="kalender1">
        <img src="img/kalender2.svg" alt="kalenderen 2" class="pictures" id="kalender2">
        <img src="img/kalender3.svg" alt="kalender 3" class="pictures" id="kalender3">
        <img src="img/kalender4.svg" loading="lazy" alt="kalender 4" class="pictures" id="kalender4">

        <img src="img/Hovedperson-01-Hovedperson-glad-gravid.svg" alt="HP er gravid" class="pictures" id="hPgravid">

        <img src="img/baby3.svg" alt="babyen ser glad ud" class="pictures" id="babyglad">
   

</div>`;

document.getElementById('s4').innerHTML= `<div class = "section" id = "section2">
<div class = "txt" id = "TxtPage2">
  <p>Nu var tiden fløjet og boblen sprunget, tilbage til livet hun var tvunget, igen panikken steg, og dog alligevel hun studerende blev. </p>
</div>

<img src="img/skole.svg" alt="Skolen som baggrund" class="pictures" id="skoleP2">
<img src="img/lyn1.svg" alt="thunder" class="pictures" id="thunder1">
<img src="img/sky2.svg" alt="sky" class="pictures" id="cloud1">
<img src="img/lyn2.svg" alt="thunder 2" class="pictures" id="thunder2">
<img src="img/sky3.svg" alt="clod3" class="pictures" id="cloud2">
<img src="img/lyn2.svg" alt="thunder 3.0" class="pictures" id="thunder3">
<img src="img/Hovedperson-02-Hovedperson-bagfra.svg" alt="HP ked af det ikke gravid" class="pictures" id="HPpage2">
<img src="img/trae3.svg" alt="skolen skinner" class="pictures" id="tree1P2">
<img src="img/trae2.svg" alt="skolen skinner" class="pictures" id="tree2P2">
</div>`;

document.getElementById('s5').innerHTML= `
<div class = "section" id = "section3">
<div class = "txt" id = "TxtPage3">
  <p>Hun følte sig lille og bange, og hurtigt blev opgaverne mange. Nu stod hun pludselig som mor og studerende, og dette føltes vældig frustrerende. </p>
</div>

<img src="img/baby.svg" alt="baggrund med baby" class="pictures" id="BGbaby">
<img src="img/Elementer-08-Papir.svg" alt="papir på bordet" class="pictures" id="opgaver">

</div>`;

document.getElementById('s6').innerHTML= `


<div class = "section" id = "section4">
<div class = "txt" id = "TxtPage4">
  <p>Ind i endnu en ny klasse hun kom, og mødte multi-musen som gav en hjælpende hånd. Et venligt hej fra multi musen om morgenen hun fik, og ind i klassen med rank ryg hun gik. </p>
</div>

<img src="img/klasse.svg" alt="klasselokale" class="pictures" id="classRoom">
<img src="img/bord.svg" alt="bordet" class="pictures" id="bordet">
<img src="img/gruppebord.svg" alt="gruppebordet" class="pictures" id="groupTable">
<img src="img/mus3.svg" alt="Multimusen" class="pictures" id="multimusen">
<img src="img/mushaand.svg" alt="" class="pictures" id="musarm">
<img src="img/computer.svg" alt="computeren" class="pictures" id="computer">
<img src="img/fe1.svg" alt="den gode fe 1" class="pictures" id="godFe1">
<img src="img/fe3.svg" alt="den gode fe 2" class="pictures" id="godFe2">
</div>`;

document.getElementById('s7').innerHTML= `
<div class = "section" id = "section5">
  <div class = "txt" id = "TxtPage5">
    <p>Nu skulle hun i første gruppe, men nervøsiteten var svær at slippe. Men med åbne arme hun fik, og snakken der hurtig gik, og pludselig opstod en god gruppedynamik. 
    </p>

   
</div>
<img src="img/klasse2.svg" alt="klasselokalet 2.0" class="pictures" id="klasse1">
<img src="img/Klassekammerat1.svg" alt="klassekammerat" class="pictures" id="classMate">
<img src="img/klassekammerat2.svg" alt="klassekammerat der også er snaksagelig" class="pictures" id="classMate2">
<img src="img/gruppebord.svg" alt="bordet til at arbejde på" class="pictures" id="bordetPage5">
<img src="img/Hovedperson-02-Hovedperson-bagfra.svg" alt="Hovedpersonen bag fra" class="pictures" id="HPBag">
<img src="img/tale.svg" alt="talebobbel" class="pictures" id="tale1">


  </div>
`;

document.getElementById('s8').innerHTML= `
<div class = "section" id = "section6">
  <div class = "txt" id = "TxtPage6">
    <p>Erhvervsakademi aarhus, tog imod hende med åbne arme, og alt hendes nervørsitet blev gjort til skamme, bedste beslutning hun kunne tag', nu blev hun snart udlært en skønne dag. 
    </p>

</div>
<img src="img/fe1.svg" alt="Fe 1 tager godt i mod jer" class="pictures" id="GodFe1S6">
<img src="img/fe3.svg" alt="Fe 2 tager godt i mod jer også" class="pictures" id="GodFe2S6">
<img src="img/mus2.svg" alt="Multimusen tager godt i mod jer" class="pictures" id="MultiMusS6">
  </div>`;

document.getElementById('s9').innerHTML= `
<div class = "section" id = "section7">
  <div class = "txt" id = "TxtPage7">
    <p>Eksamen hun bestod til UG, den gik så godt som hun kunne be. Nu skulle hun ud i erhvervslivet, for nu var hun ikke så pivet. Klar til virkeligheden hun var blevet, med hjælp fra akademi livet. Hendes baby nu en god fremtid fik, Studerende forældre er en god dynamik. </p>
</div>
  <img src="img/Untitled-12-Hovedperson-superhelt.svg" alt="som bestået blev mor til en supermor" class="pictures" id="superMom">
  </div>`;


/*
  document.getElementById('s10').innerHTML= `      <!-- 1. The <iframe> (and video player) will replace this <div> tag. -->
  <div id="flexplayer">
  <div><p>Hvorfor valgte i at studere efter i har fået barn/børn?</p><div id="player1"></div></div>
  
  
  <div><p>Hvilke fordele og ulemper synes i der er ved at studere mens man har børn?</p><div id="player2"></div></div>

  <div><p>Hvordan får i din økonomi som studerende med børn til at hænge sammen?</p><div id="player3"></div></div>

  <div><p>Hvordan strukturerer i din hverdag omkring studiet og familien?</p><div id="player4"></div></div>

  <div><p>Hvorfor valgte i at studere på Aarhus Erhvervsakademi?</p><div id="player5"></div></div>

</div>
`;*/