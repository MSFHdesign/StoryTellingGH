var password; 
var pass1="meget_hemmeligt"; 

password=prompt('Hva\' koden?',''); 
if (password==pass1) 
alert('Koden er ...korrekt! Du er værdig til at forsætte'); 
else { window.location="https://storytelling.msfh.dk/"; 
} 