var myFullpage = new fullpage('#fullpage', {
  sectionsColor: ['#f2f2f2', '#4BBFC3', '#7BAABE', 'whitesmoke', '#ccddff'],
  lazyLoading:true,
  keyboardScrolling:true,

});
